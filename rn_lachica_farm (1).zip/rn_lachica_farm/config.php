<?php
session_start();
date_default_timezone_set('Asia/Manila');
$pdo = new PDO('mysql:host=localhost;dbname=rn_lachica_farm;charset=utf8mb4', 'root', '', [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
]);
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES); }
function flash($m){ $_SESSION['flash'] = $m; }
function go($u){ header("Location: $u"); exit; }
function age($d){ return (int)((strtotime(date('Y-m-d')) - strtotime($d)) / 86400); }

// Notifications: vitamins due, harvest ready, low stock
function notifications($pdo){
  $n = [];
  $batches = $pdo->query("SELECT * FROM batches WHERE status='active'")->fetchAll();
  foreach($batches as $b){
    $a = age($b['date_started']); $left = $b['harvest_days'] - $a;
    if($left <= 0) $n[] = ['danger', "🐔 READY TO HARVEST na ang {$b['batch_name']} ({$a} days old)!"];
    elseif($left <= 3) $n[] = ['warn', "⏰ {$b['batch_name']}: {$left} day(s) na lang bago ang harvest."];
  }
  if($batches){
    $start = min(array_column($batches, 'date_started'));
    foreach($pdo->query("SELECT * FROM vitamins")->fetchAll() as $v){
      $base = $v['last_given'] ?: $start;
      $due = strtotime($base . " +{$v['interval_days']} days");
      if(strtotime(date('Y-m-d')) >= $due) $n[] = ['danger', "💊 Oras na magbigay ng vitamins: {$v['name']} (every {$v['interval_days']} days)."];
    }
  }
  foreach($pdo->query("SELECT * FROM feeds WHERE stock_kg <= 10")->fetchAll() as $f)
    $n[] = ['warn', "🌾 Paubos na ang feeds: {$f['name']} ({$f['stock_kg']} kg na lang)."];
  foreach($pdo->query("SELECT * FROM vitamins WHERE stock <= 5")->fetchAll() as $v)
    $n[] = ['warn', "💊 Paubos na ang vitamins: {$v['name']} ({$v['stock']} {$v['unit']} na lang)."];
  return $n;
}
