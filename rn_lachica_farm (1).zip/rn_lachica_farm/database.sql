CREATE DATABASE IF NOT EXISTS rn_lachica_farm CHARACTER SET utf8mb4;
USE rn_lachica_farm;

CREATE TABLE IF NOT EXISTS batches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  batch_name VARCHAR(100) NOT NULL,
  quantity INT NOT NULL DEFAULT 0,
  date_started DATE NOT NULL,
  harvest_days INT NOT NULL DEFAULT 35,
  status ENUM('active','harvested') DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS feeds (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  stock_kg DECIMAL(10,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS vitamins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  stock DECIMAL(10,2) NOT NULL DEFAULT 0,
  unit VARCHAR(20) NOT NULL DEFAULT 'pcs',
  interval_days INT NOT NULL DEFAULT 7,
  last_given DATE NULL
);

CREATE TABLE IF NOT EXISTS vitamin_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vitamin_id INT NOT NULL,
  qty_used DECIMAL(10,2) NOT NULL,
  date_given DATE NOT NULL,
  FOREIGN KEY (vitamin_id) REFERENCES vitamins(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS harvest_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  batch_name VARCHAR(100),
  quantity_started INT,
  quantity_harvested INT,
  date_started DATE,
  date_harvested DATE,
  age_days INT
);

INSERT INTO feeds(name,stock_kg) VALUES ('Starter Feeds',50),('Grower Feeds',100);
INSERT INTO vitamins(name,stock,unit,interval_days) VALUES ('Multivitamins',20,'sachet',7);
CREATE TABLE IF NOT EXISTS mortality (
  id INT AUTO_INCREMENT PRIMARY KEY,
  batch_id INT NOT NULL,
  qty INT NOT NULL,
  reason VARCHAR(150),
  date_lost DATE NOT NULL,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE
);
