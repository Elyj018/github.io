<?php require 'config.php'; require 'layout.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $a=$_POST['a'];
  if($a=='save'){
    if($_POST['id']) $pdo->prepare("UPDATE feeds SET name=?,stock_kg=? WHERE id=?")->execute([trim($_POST['name']),(float)$_POST['stock_kg'],$_POST['id']]);
    else $pdo->prepare("INSERT INTO feeds(name,stock_kg) VALUES(?,?)")->execute([trim($_POST['name']),(float)$_POST['stock_kg']]);
    flash('Na-save ang feeds.');
  }
  if($a=='add')  { $pdo->prepare("UPDATE feeds SET stock_kg=stock_kg+? WHERE id=?")->execute([(float)$_POST['kg'],$_POST['id']]); flash('Nadagdagan ang feeds.'); }
  if($a=='use')  { $pdo->prepare("UPDATE feeds SET stock_kg=GREATEST(0,stock_kg-?) WHERE id=?")->execute([(float)$_POST['kg'],$_POST['id']]); flash('Nabawasan ang feeds.'); }
  if($a=='del')  { $pdo->prepare("DELETE FROM feeds WHERE id=?")->execute([$_POST['id']]); flash('Na-delete.'); }
  go('feeds.php');
}
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM feeds WHERE id=?"); $s->execute([$_GET['edit']]); $edit=$s->fetch(); }
head('Feeds');
$rows=$pdo->query("SELECT * FROM feeds ORDER BY name")->fetchAll();
?>
<div class="card"><h3><?= $edit?'I-edit':'Mag-add ng' ?> Feeds / Patuka</h3>
<form method="post"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="<?= $edit['id']??'' ?>">
<div class="row"><div>Pangalan<input name="name" required value="<?= e($edit['name']??'') ?>"></div>
<div>Stock (kg)<input type="number" step="0.01" min="0" name="stock_kg" required value="<?= e($edit['stock_kg']??'') ?>"></div></div>
<br><button>💾 Save</button> <?php if($edit): ?><a class="btn s" href="feeds.php">Cancel</a><?php endif; ?></form></div>
<div class="card"><h3>Stock ng Feeds</h3>
<table><tr><th>Feeds</th><th>Natitira (kg)</th><th>Dagdag</th><th>Gamit</th><th>Action</th></tr>
<?php foreach($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><b><?= $r['stock_kg'] ?> kg</b></td>
<td><form method="post" class="inline"><input type="hidden" name="a" value="add"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="number" step="0.01" min="0" name="kg" placeholder="kg" required><button class="g">+</button></form></td>
<td><form method="post" class="inline"><input type="hidden" name="a" value="use"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="number" step="0.01" min="0" name="kg" placeholder="kg" required><button class="r">−</button></form></td>
<td><a class="btn" href="?edit=<?= $r['id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('I-delete?')"><input type="hidden" name="a" value="del"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="r">Delete</button></form></td></tr>
<?php endforeach; ?></table></div>
<?php foot(); ?>
