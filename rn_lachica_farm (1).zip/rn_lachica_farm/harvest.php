<?php require 'config.php'; require 'layout.php';
if($_SERVER['REQUEST_METHOD']=='POST' && $_POST['a']=='harvest'){
  $s=$pdo->prepare("SELECT * FROM batches WHERE id=? AND status='active'"); $s->execute([$_POST['id']]); $b=$s->fetch();
  if($b){
    $pdo->prepare("INSERT INTO harvest_history(batch_name,quantity_started,quantity_harvested,date_started,date_harvested,age_days) VALUES(?,?,?,?,CURDATE(),?)")
        ->execute([$b['batch_name'],$b['quantity'],(int)$_POST['harvested'],$b['date_started'],age($b['date_started'])]);
    // RESET: manok, feeds, vitamins
    $pdo->prepare("UPDATE batches SET status='harvested', quantity=0 WHERE id=?")->execute([$b['id']]);
    if(!empty($_POST['reset_supplies'])){
      $pdo->exec("UPDATE feeds SET stock_kg=0");
      $pdo->exec("UPDATE vitamins SET stock=0, last_given=NULL");
    }
    flash("Na-harvest ang {$b['batch_name']}. Na-reset na ang bilang.");
  }
  go('harvest.php');
}
head('Harvest');
$rows=$pdo->query("SELECT * FROM batches WHERE status='active' ORDER BY date_started")->fetchAll();
$hist=$pdo->query("SELECT * FROM harvest_history ORDER BY id DESC")->fetchAll();
?>
<div class="card"><h3>Harvest at Reset</h3>
<table><tr><th>Batch</th><th>Dami</th><th>Edad</th><th>Status</th><th>Harvest / Reset</th></tr>
<?php foreach($rows as $r): $a=age($r['date_started']); $ready=$a>=$r['harvest_days']; ?>
<tr><td><?= e($r['batch_name']) ?></td><td><?= $r['quantity'] ?></td><td><?= $a ?> days</td>
<td><?= $ready?'✅ Ready to harvest':'⏳ '.($r['harvest_days']-$a).' day(s) pa' ?></td>
<td><form method="post" onsubmit="return confirm('Sigurado ka? Ire-reset ang bilang ng manok<?= '' ?>.')">
<input type="hidden" name="a" value="harvest"><input type="hidden" name="id" value="<?= $r['id'] ?>">
<input type="number" min="0" name="harvested" value="<?= $r['quantity'] ?>" required style="width:100px" title="Ilan ang na-harvest">
<label><input type="checkbox" name="reset_supplies" value="1" checked style="width:auto"> I-reset din feeds & vitamins</label>
<button class="r">🔄 Harvest & Reset</button></form></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan=5>Walang active na batch.</td></tr>'; ?></table></div>
<div class="card"><h3>Harvest History</h3>
<table><tr><th>Batch</th><th>Simula</th><th>Na-harvest</th><th>Nag-start</th><th>Na-harvest</th><th>Edad</th></tr>
<?php foreach($hist as $h): ?><tr><td><?= e($h['batch_name']) ?></td><td><?= $h['date_started'] ?></td><td><?= $h['date_harvested'] ?></td>
<td><?= $h['quantity_started'] ?></td><td><?= $h['quantity_harvested'] ?></td><td><?= $h['age_days'] ?> days</td></tr>
<?php endforeach; ?></table></div>
<?php foot(); ?>
