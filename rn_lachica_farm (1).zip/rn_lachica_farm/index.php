<?php require 'config.php'; require 'layout.php'; head('Dashboard');
$b = $pdo->query("SELECT * FROM batches WHERE status='active' ORDER BY date_started")->fetchAll();
$tot = array_sum(array_column($b,'quantity'));
$fk = (float)$pdo->query("SELECT COALESCE(SUM(stock_kg),0) FROM feeds")->fetchColumn();
$vc = (float)$pdo->query("SELECT COALESCE(SUM(stock),0) FROM vitamins")->fetchColumn();
$dead = (int)$pdo->query("SELECT COALESCE(SUM(qty),0) FROM mortality")->fetchColumn();
// Estimated daily feed need (g/bird/day: <=14d 30g, <=28d 80g, older 120g)
$need=0; foreach($b as $r){ $a=age($r['date_started']); $need += $r['quantity']*($a<=14?30:($a<=28?80:120))/1000; }
$days = $need>0 ? floor($fk/$need) : null;
?>
<div class="grid">
<div class="card stat"><span class="ic">🐔</span><p>Kabuuang Manok</p><h2><?= number_format($tot) ?></h2><small><?= count($b) ?> active batch</small></div>
<div class="card stat"><span class="ic">🌾</span><p>Feeds</p><h2><?= $fk ?> kg</h2><small><?= $days!==null ? "~$days araw na lang (estimate)" : 'walang active batch' ?></small></div>
<div class="card stat"><span class="ic">💊</span><p>Vitamins</p><h2><?= $vc ?></h2><small>total stock</small></div>
<div class="card stat"><span class="ic">⚠️</span><p>Namatay</p><h2><?= $dead ?></h2><small>lahat ng batch</small></div>
</div>
<div class="card"><h3>🐥 Age Monitoring</h3><div class="bcards">
<?php foreach($b as $r): $a=age($r['date_started']); $p=min(100,round($a/$r['harvest_days']*100)); $left=$r['harvest_days']-$a;
$col=$left<=0?'#3d8b40':($left<=3?'#c0392b':'#e8a317'); ?>
<div class="bc"><div class="ring" style="background:conic-gradient(<?= $col ?> <?= $p ?>%,var(--line) 0)"><div><span><?= $a ?><small>days</small></span></div></div>
<div><b><?= e($r['batch_name']) ?></b><br><?= number_format($r['quantity']) ?> manok<br>
<span class="pill <?= $left<=0?'g':($left<=3?'r':'y') ?>"><?= $left<=0?'✅ Ready harvest':"$left day(s) pa" ?></span></div></div>
<?php endforeach; if(!$b) echo '<p>Wala pang active na batch. Pumunta sa <a href="manok.php">Manok</a> para mag-add.</p>'; ?>
</div></div>
<div class="card"><h3>⚡ Quick Actions</h3>
<a class="btn" href="manok.php">🐥 Add Batch</a> <a class="btn g" href="feeds.php">🌾 Update Feeds</a>
<a class="btn" href="vitamins.php">💊 Give Vitamins</a> <a class="btn r" href="harvest.php">🥚 Harvest</a></div>
<?php foot(); ?>
