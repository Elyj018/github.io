<?php
function head($title){ global $pdo; $notes = notifications($pdo); $cur = basename($_SERVER['PHP_SELF'],'.php');
$danger = array_values(array_filter($notes, fn($x)=>$x[0]=='danger')); ?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> | RN Lachica's Farm</title>
<script>if(localStorage.getItem('dark')==='1')document.documentElement.classList.add('dark')</script>
<style>
:root{--bg:#fff8e7;--card:#fff;--ink:#3b2a1a;--mut:#8a7560;--pri:#e8a317;--pri2:#c47f00;--red:#c0392b;--grn:#3d8b40;--line:#f1e4c8;--side:#4a2c17}
.dark{--bg:#1a1410;--card:#262019;--ink:#f3e9d8;--mut:#a89580;--line:#3a3025;--side:#0f0b08}
*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--ink);display:flex;min-height:100vh}
aside{width:230px;background:var(--side);color:#fff;padding:20px 14px;position:sticky;top:0;height:100vh;flex-shrink:0}
.logo{display:flex;align-items:center;gap:10px;margin-bottom:26px;font-weight:800;line-height:1.1}
.logo span.e{font-size:36px;background:var(--pri);border-radius:14px;padding:4px 8px}.logo small{display:block;font-weight:400;opacity:.7;font-size:11px}
aside a{display:flex;gap:10px;align-items:center;color:#f5e6cc;text-decoration:none;padding:11px 14px;border-radius:12px;margin-bottom:4px;font-weight:500}
aside a:hover{background:#ffffff18}aside a.on{background:var(--pri);color:#3b2a1a;font-weight:700}
.wrap{flex:1;min-width:0}
.top{display:flex;justify-content:space-between;align-items:center;padding:16px 28px;border-bottom:1px solid var(--line)}
.top h1{margin:0;font-size:22px}.top small{color:var(--mut)}
.tools{display:flex;gap:8px}.tools button{background:var(--card);color:var(--ink);border:1px solid var(--line);font-size:18px;padding:7px 12px;border-radius:12px}
main{padding:22px 28px;max-width:1150px}
.card{background:var(--card);border-radius:18px;padding:20px;margin-bottom:20px;border:1px solid var(--line);box-shadow:0 4px 14px #7a4b1e12}
.card h3{margin-top:0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin-bottom:20px}.grid .card{margin:0}
.stat{text-align:left;position:relative;overflow:hidden}.stat p{margin:0;color:var(--mut);font-size:13px;font-weight:600;text-transform:uppercase}
.stat h2{margin:6px 0 0;font-size:34px}.stat small{color:var(--mut)}.stat .ic{position:absolute;right:12px;top:8px;font-size:40px;opacity:.9}
table{width:100%;border-collapse:collapse}th,td{padding:11px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}
th{color:var(--mut);font-size:12px;text-transform:uppercase}
input,select{padding:10px 12px;border:1px solid var(--line);border-radius:10px;margin:3px 0;width:100%;background:var(--bg);color:var(--ink);font-size:14px}
.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
button,.btn{background:var(--pri);color:#3b2a1a;border:0;padding:9px 15px;border-radius:10px;cursor:pointer;text-decoration:none;font-size:14px;font-weight:700;display:inline-block}
button:hover,.btn:hover{background:var(--pri2);color:#fff}
.btn.r,button.r{background:var(--red);color:#fff}.btn.g,button.g{background:var(--grn);color:#fff}.btn.s,button.s{background:#8a7560;color:#fff}
.inline{display:inline-flex;gap:4px;align-items:center;margin:2px}.inline input{width:75px}
.alert{padding:13px 16px;border-radius:14px;margin-bottom:9px;font-weight:600}
.alert.danger{background:#fde3e1;color:#8a1c14;border-left:6px solid var(--red)}
.alert.warn{background:#fff1c9;color:#7a5a00;border-left:6px solid var(--pri)}
.dark .alert.danger{background:#4a1d19;color:#ffb4ab}.dark .alert.warn{background:#4a3a10;color:#ffd97a}
.ok{background:#e0f2e1;color:#1b5e20;padding:12px 16px;border-radius:14px;margin-bottom:14px;font-weight:600}
.bar{background:var(--line);border-radius:99px;height:14px;overflow:hidden}.bar i{display:block;height:100%;background:linear-gradient(90deg,#f5c542,#e8a317);border-radius:99px}
.pill{padding:4px 10px;border-radius:99px;font-size:12px;font-weight:700;background:var(--line)}
.pill.g{background:#d8f0da;color:#1b5e20}.pill.r{background:#fde3e1;color:#8a1c14}.pill.y{background:#fff1c9;color:#7a5a00}
.bcards{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px}
.bc{display:flex;gap:14px;align-items:center;border:1px solid var(--line);border-radius:16px;padding:14px}
.ring{width:84px;height:84px;border-radius:50%;display:grid;place-items:center;flex-shrink:0}
.ring div{width:64px;height:64px;border-radius:50%;background:var(--card);display:grid;place-items:center;font-weight:800;font-size:18px;text-align:center;line-height:1}
.ring small{display:block;font-size:10px;color:var(--mut);font-weight:600}
.modal{position:fixed;inset:0;background:#000a;display:none;place-items:center;z-index:99}.modal.show{display:grid}
.modal .box{background:var(--card);border-radius:20px;padding:24px;max-width:460px;width:92%}
.modal h2{margin-top:0;color:var(--red)}
@media(max-width:800px){body{flex-direction:column}aside{width:100%;height:auto;position:static;display:flex;overflow-x:auto;gap:4px;padding:10px}
.logo{margin:0 10px 0 0}.logo small{display:none}aside a{white-space:nowrap}main,.top{padding:14px}}
@media print{aside,.tools,.alert,.no-print{display:none}}
</style></head><body>
<aside><div class="logo"><span class="e">🐔</span><div>RN Lachica's<small>Poultry Farm System</small></div></div>
<?php foreach(['index'=>['🏠','Dashboard'],'manok'=>['🐥','Manok'],'feeds'=>['🌾','Feeds'],'vitamins'=>['💊','Vitamins'],'harvest'=>['🥚','Harvest'],'reports'=>['📊','Statistics']] as $f=>$l): ?>
<a href="<?= $f ?>.php" class="<?= $cur==$f?'on':'' ?>"><span><?= $l[0] ?></span><?= $l[1] ?></a><?php endforeach; ?></aside>
<div class="wrap"><div class="top"><div><h1><?= e($title) ?></h1><small><?= date('l, F j, Y') ?></small></div>
<div class="tools"><button onclick="document.getElementById('nm').classList.add('show')" title="Notifications">🔔 <?= count($notes) ?></button>
<button onclick="document.documentElement.classList.toggle('dark');localStorage.setItem('dark',document.documentElement.classList.contains('dark')?'1':'0')" title="Dark mode">🌙</button></div></div>
<main>
<?php if(!empty($_SESSION['flash'])): ?><div class="ok">✅ <?= e($_SESSION['flash']) ?></div><?php unset($_SESSION['flash']); endif;
foreach($notes as $x): ?><div class="alert <?= $x[0] ?>"><?= e($x[1]) ?></div><?php endforeach; ?>
<div class="modal" id="nm" onclick="if(event.target==this)this.classList.remove('show')"><div class="box"><h2>🔔 Mga Notification</h2>
<?php foreach($notes as $x): ?><div class="alert <?= $x[0] ?>"><?= e($x[1]) ?></div><?php endforeach; if(!$notes) echo '<p>Wala pang notification. Okay lahat! 🐔</p>'; ?>
<button onclick="document.getElementById('nm').classList.remove('show')">OK</button></div></div>
<script>
<?php if($danger): ?>if(!sessionStorage.getItem('shown')){sessionStorage.setItem('shown','1');document.getElementById('nm').classList.add('show');
try{const c=new AudioContext(),o=c.createOscillator();o.connect(c.destination);o.frequency.value=880;o.start();setTimeout(()=>o.stop(),350)}catch(e){}}<?php endif; ?>
</script>
<?php }
function foot(){ echo '</main></div></body></html>'; }
