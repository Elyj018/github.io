<?php require 'config.php'; require 'layout.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
  if($_POST['a']=='save'){
    $d=[trim($_POST['batch_name']),(int)$_POST['quantity'],$_POST['date_started'],max(1,(int)$_POST['harvest_days'])];
    if($_POST['id']){ $d[]=$_POST['id']; $pdo->prepare("UPDATE batches SET batch_name=?,quantity=?,date_started=?,harvest_days=? WHERE id=?")->execute($d); }
    else $pdo->prepare("INSERT INTO batches(batch_name,quantity,date_started,harvest_days) VALUES(?,?,?,?)")->execute($d);
    flash('Na-save ang batch ng manok.');
  }
  if($_POST['a']=='del'){ $pdo->prepare("DELETE FROM batches WHERE id=?")->execute([$_POST['id']]); flash('Na-delete ang batch.'); }
  if($_POST['a']=='dead'){ $q=max(0,(int)$_POST['qty']);
    $pdo->prepare("UPDATE batches SET quantity=GREATEST(0,quantity-?) WHERE id=?")->execute([$q,$_POST['id']]);
    $pdo->prepare("INSERT INTO mortality(batch_id,qty,reason,date_lost) VALUES(?,?,?,CURDATE())")->execute([$_POST['id'],$q,trim($_POST['reason'])]);
    flash("Naitala ang $q na patay na manok."); }
  go('manok.php');
}
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM batches WHERE id=?"); $s->execute([$_GET['edit']]); $edit=$s->fetch(); }
head('Manok');
$rows=$pdo->query("SELECT * FROM batches WHERE status='active' ORDER BY id DESC")->fetchAll();
?>
<div class="card"><h3><?= $edit?'I-edit':'Mag-add ng' ?> Batch ng Manok</h3>
<form method="post"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="<?= $edit['id']??'' ?>">
<div class="row">
<div>Pangalan ng Batch<input name="batch_name" required value="<?= e($edit['batch_name']??'') ?>" placeholder="Batch 1"></div>
<div>Dami (pcs)<input type="number" min="0" name="quantity" required value="<?= e($edit['quantity']??'') ?>"></div>
<div>Petsa ng Simula<input type="date" name="date_started" required value="<?= e($edit['date_started']??date('Y-m-d')) ?>"></div>
<div>Harvest after (days)<input type="number" min="1" name="harvest_days" required value="<?= e($edit['harvest_days']??35) ?>"></div>
</div><br><button>💾 Save</button> <?php if($edit): ?><a class="btn s" href="manok.php">Cancel</a><?php endif; ?></form></div>
<div class="card"><h3>Listahan ng Manok</h3>
<table><tr><th>Batch</th><th>Dami</th><th>Simula</th><th>Edad</th><th>Harvest</th><th>Patay</th><th>Action</th></tr>
<?php foreach($rows as $r): ?><tr><td><?= e($r['batch_name']) ?></td><td><?= $r['quantity'] ?></td><td><?= $r['date_started'] ?></td>
<td><?= age($r['date_started']) ?> days</td><td><?= $r['harvest_days'] ?> days</td>
<td><form method="post" class="inline"><input type="hidden" name="a" value="dead"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="number" min="1" name="qty" placeholder="ilan" required><input name="reason" placeholder="dahilan" style="width:90px"><button class="r">☠</button></form></td>
<td><a class="btn" href="?edit=<?= $r['id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('I-delete ang batch?')"><input type="hidden" name="a" value="del"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="r">Delete</button></form></td></tr>
<?php endforeach; ?></table></div>
<?php foot(); ?>
