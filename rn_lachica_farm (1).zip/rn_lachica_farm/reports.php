<?php require 'config.php'; require 'layout.php'; head('Statistics');
$feeds=$pdo->query("SELECT * FROM feeds")->fetchAll();
$vits=$pdo->query("SELECT * FROM vitamins")->fetchAll();
$act=$pdo->query("SELECT COALESCE(SUM(quantity),0) t, COUNT(*) c FROM batches WHERE status='active'")->fetch();
$h=$pdo->query("SELECT COUNT(*) c, COALESCE(SUM(quantity_harvested),0) t, COALESCE(SUM(quantity_started),0) s, COALESCE(AVG(age_days),0) a FROM harvest_history")->fetch();
$logs=$pdo->query("SELECT l.*, v.name, v.unit FROM vitamin_logs l JOIN vitamins v ON v.id=l.vitamin_id ORDER BY l.id DESC LIMIT 15")->fetchAll();
$mx=max(1,...array_map(fn($f)=>(float)$f['stock_kg'],$feeds?:[['stock_kg'=>1]]));
$mv=max(1,...array_map(fn($v)=>(float)$v['stock'],$vits?:[['stock'=>1]]));
$surv=$h['s']>0?round($h['t']/$h['s']*100,1):0;
?>
<div class="no-print" style="text-align:right;margin-bottom:10px"><button onclick="window.print()">🖨 Print Report</button></div>
<div class="grid">
<div class="card stat"><p>Manok (Active)</p><h2><?= $act['t'] ?></h2><small><?= $act['c'] ?> batch(es)</small></div>
<div class="card stat"><p>Total Harvested</p><h2><?= $h['t'] ?></h2><small><?= $h['c'] ?> harvest(s)</small></div>
<div class="card stat"><p>Survival Rate</p><h2><?= $surv ?>%</h2><small>harvested / started</small></div>
<div class="card stat"><p>Avg. Edad ng Harvest</p><h2><?= round($h['a']) ?></h2><small>days</small></div>
</div>
<div class="card"><h3>Feeds Inventory</h3>
<?php foreach($feeds as $f): ?><p><?= e($f['name']) ?> — <b><?= $f['stock_kg'] ?> kg</b></p><div class="bar"><i style="width:<?= $f['stock_kg']/$mx*100 ?>%;background:<?= $f['stock_kg']<=10?'#b3261e':'#2e7d32' ?>"></i></div><?php endforeach; ?></div>
<div class="card"><h3>Vitamins Inventory</h3>
<?php foreach($vits as $v): ?><p><?= e($v['name']) ?> — <b><?= $v['stock'] ?> <?= e($v['unit']) ?></b></p><div class="bar"><i style="width:<?= $v['stock']/$mv*100 ?>%;background:<?= $v['stock']<=5?'#b3261e':'#2e7d32' ?>"></i></div><?php endforeach; ?></div>
<div class="card"><h3>Huling Pagbibigay ng Vitamins</h3>
<table><tr><th>Petsa</th><th>Vitamins</th><th>Ginamit</th></tr>
<?php foreach($logs as $l): ?><tr><td><?= $l['date_given'] ?></td><td><?= e($l['name']) ?></td><td><?= $l['qty_used'] ?> <?= e($l['unit']) ?></td></tr><?php endforeach; ?></table></div>
<div class="card"><h3>☠ Mortality (Namatay na Manok)</h3>
<?php $ml=$pdo->query("SELECT m.*,b.batch_name FROM mortality m JOIN batches b ON b.id=m.batch_id ORDER BY m.id DESC LIMIT 15")->fetchAll(); ?>
<table><tr><th>Petsa</th><th>Batch</th><th>Dami</th><th>Dahilan</th></tr>
<?php foreach($ml as $m): ?><tr><td><?= $m['date_lost'] ?></td><td><?= e($m['batch_name']) ?></td><td><?= $m['qty'] ?></td><td><?= e($m['reason']) ?></td></tr><?php endforeach; if(!$ml) echo '<tr><td colspan=4>Walang naitalang patay.</td></tr>'; ?></table></div>
<style>@media print{nav,.no-print,.alert{display:none}}</style>
<?php foot(); ?>
