USE rn_lachica_farm;
CREATE TABLE IF NOT EXISTS mortality (
  id INT AUTO_INCREMENT PRIMARY KEY,
  batch_id INT NOT NULL,
  qty INT NOT NULL,
  reason VARCHAR(150),
  date_lost DATE NOT NULL,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE
);
