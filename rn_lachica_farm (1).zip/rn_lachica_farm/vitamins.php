<?php require 'config.php'; require 'layout.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $a=$_POST['a'];
  if($a=='save'){
    $d=[trim($_POST['name']),(float)$_POST['stock'],trim($_POST['unit']),max(1,(int)$_POST['interval_days'])];
    if($_POST['id']){ $d[]=$_POST['id']; $pdo->prepare("UPDATE vitamins SET name=?,stock=?,unit=?,interval_days=? WHERE id=?")->execute($d); }
    else $pdo->prepare("INSERT INTO vitamins(name,stock,unit,interval_days) VALUES(?,?,?,?)")->execute($d);
    flash('Na-save ang vitamins.');
  }
  if($a=='add'){ $pdo->prepare("UPDATE vitamins SET stock=stock+? WHERE id=?")->execute([(float)$_POST['qty'],$_POST['id']]); flash('Nadagdagan ang stock.'); }
  if($a=='give'){
    $q=(float)$_POST['qty'];
    $pdo->prepare("UPDATE vitamins SET stock=GREATEST(0,stock-?),last_given=CURDATE() WHERE id=?")->execute([$q,$_POST['id']]);
    $pdo->prepare("INSERT INTO vitamin_logs(vitamin_id,qty_used,date_given) VALUES(?,?,CURDATE())")->execute([$_POST['id'],$q]);
    flash('Naibigay na ang vitamins. Na-reset ang countdown ng notification.');
  }
  if($a=='del'){ $pdo->prepare("DELETE FROM vitamins WHERE id=?")->execute([$_POST['id']]); flash('Na-delete.'); }
  go('vitamins.php');
}
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare("SELECT * FROM vitamins WHERE id=?"); $s->execute([$_GET['edit']]); $edit=$s->fetch(); }
head('Vitamins');
$rows=$pdo->query("SELECT * FROM vitamins ORDER BY name")->fetchAll();
?>
<div class="card"><h3><?= $edit?'I-edit':'Mag-add ng' ?> Vitamins</h3>
<form method="post"><input type="hidden" name="a" value="save"><input type="hidden" name="id" value="<?= $edit['id']??'' ?>">
<div class="row"><div>Pangalan<input name="name" required value="<?= e($edit['name']??'') ?>"></div>
<div>Stock<input type="number" step="0.01" min="0" name="stock" required value="<?= e($edit['stock']??'') ?>"></div>
<div>Unit<input name="unit" required value="<?= e($edit['unit']??'pcs') ?>" placeholder="pcs / sachet / ml"></div>
<div>Notify every (days)<input type="number" min="1" name="interval_days" required value="<?= e($edit['interval_days']??7) ?>"></div></div>
<br><button>💾 Save</button> <?php if($edit): ?><a class="btn s" href="vitamins.php">Cancel</a><?php endif; ?></form></div>
<div class="card"><h3>Stock ng Vitamins</h3>
<table><tr><th>Vitamins</th><th>Natitira</th><th>Every</th><th>Huling Bigay</th><th>Dagdag Stock</th><th>Bigay Ngayon</th><th>Action</th></tr>
<?php foreach($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><b><?= $r['stock'] ?> <?= e($r['unit']) ?></b></td>
<td><?= $r['interval_days'] ?> days</td><td><?= $r['last_given']?:'—' ?></td>
<td><form method="post" class="inline"><input type="hidden" name="a" value="add"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="number" step="0.01" min="0" name="qty" placeholder="qty" required><button class="g">+</button></form></td>
<td><form method="post" class="inline"><input type="hidden" name="a" value="give"><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="number" step="0.01" min="0" name="qty" placeholder="gamit" required><button>💊 Give</button></form></td>
<td><a class="btn" href="?edit=<?= $r['id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('I-delete?')"><input type="hidden" name="a" value="del"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="r">Delete</button></form></td></tr>
<?php endforeach; ?></table></div>
<?php foot(); ?>
